Version 1.30.4 (November 9, 2026)
=================================

### Security
- fixed a local file disclosure vulnerability that allowed custom XSLT policies to read local XML files through document() ([GHSA-73f4-hgcx-xc59](https://github.com/veraPDF/veraPDF-validation/security/advisories/GHSA-73f4-hgcx-xc59); [commit](https://github.com/veraPDF/veraPDF-library/commit/e74076a68832b024f643a49656a8d245f5884d83))

### Jakarta
- aligned the Jakarta version with the javax version: changes that were missing in the core-jakarta 1.30.3 are now included

### Docker images
- added linux/arm64 builds alongside linux/amd64 for the CLI, REST, and Arlington Docker images (commits [1](https://github.com/veraPDF/veraPDF-apps/commit/b1de5f18b0e6760a27d83364dfe395daa1069572) [2](https://github.com/veraPDF/veraPDF-apps/commit/2233f2cea78109c4c9a0801afd3c61a634b007de))

### Validation
- (PDF/UA-1,2, WTPDF-1) fixed handling of the rule about a missing parent element ([commit](https://github.com/veraPDF/veraPDF-parser/commit/cdbd343b729ec7769db172f72a27fa21450b033b))
- (PDF/UA-1) fixed rule 7.18.1-3 to apply the alternative-description requirement only to Widget annotations associated with form fields ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/b76c28ff0d8809c30c4d0e64dc6c393f3c9019dc))

### Core library
- fixed invalid JSON output in feature reports ([commit](https://github.com/veraPDF/veraPDF-library/commit/0ca733012181d0c093e31f0ce65d654a4de3556d))
- restored the original Adobe XMP Toolkit license and README, added copyright and license notices for veraPDF additions, and prevented veraPDF GPL/MPL headers from being added to XMP source files (commits [1](https://github.com/veraPDF/veraPDF-library/commit/660cb81a70a754ec8b2e78bb37a5176ce9434e9c) [2](https://github.com/veraPDF/veraPDF-library/commit/02b252f57ea308aacbf1485dd167f0598dbf687f) [3](https://github.com/veraPDF/veraPDF-library/commit/36e3b58c57e9447c2828e22fcbb2a223561bc071))

### PDF Parser
- fixed a race condition that could return a null PDF name when the dynamic name cache was cleared concurrently ([commit](https://github.com/veraPDF/veraPDF-parser/commit/f422c5bbe0a232bf0f617c2a9030e21aa1deed54))

Version 1.30.3 (October 7, 2026)
=================================

### Security
- fixed excessive resource consumption caused by recursive validation of nested embedded files ([GHSA-q2xp-cmwp-7cjh](https://github.com/veraPDF/veraPDF-validation/security/advisories/GHSA-q2xp-cmwp-7cjh); commits [1](https://github.com/veraPDF/veraPDF-validation/commit/d9f49545d7949ce18f51ba09691e0591e4f20cff) [2](https://github.com/veraPDF/veraPDF-validation/commit/5b9960eaa881fcbc6ceb0bc877f21e5845365a88))
- fixed XML parser configuration that prevented security settings from being applied, restoring protection against XML external entity attacks ([GHSA-5gvp-6g43-g47v](https://github.com/veraPDF/veraPDF-library/security/advisories/GHSA-5gvp-6g43-g47v); [commit](https://github.com/veraPDF/veraPDF-library/commit/4b2e07dd2b85ef9fb9fb7eb03e22685b84be14b8))
- fixed potential excessive memory allocation when parsing CFF font INDEX structures with a corrupted data size or offset size ([GHSA-fg6c-v27x-ffpx](https://github.com/veraPDF/veraPDF-parser/security/advisories/GHSA-fg6c-v27x-ffpx); [commit](https://github.com/veraPDF/veraPDF-parser/commit/4f0c08e5a6aae1344d24a46fa1168f5ce37cbcdc))
- fixed potential stack overflow and excessive resource consumption caused by deeply nested procedures in Type 4 functions ([GHSA-3pqj-5xfj-xrh9](https://github.com/veraPDF/veraPDF-parser/security/advisories/GHSA-3pqj-5xfj-xrh9); [commit](https://github.com/veraPDF/veraPDF-parser/commit/4ba3042f0e548b30e8ecc2b2cacae80fadb4a77b))

### Validation
- (PDF/UA-2, WTPDF-1) added a rule requiring PDF version 2.0 ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/bf09279dbc9b3f2879134b2c85670a2613955a92))
- (PDF/UA-2, WTPDF-1) improved descriptions for rules 8.2.5.20-1 and 8.9.2.3-1 ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/f6dec3ae5232400f14c576609ffa84c0d885dae7))
- (PDF/UA-2, WTPDF-1) corrected the error message for rule 8.2.5.20-2 (commits [1](https://github.com/veraPDF/veraPDF-validation-profiles/commit/0da6ee4ea63a7efbebeaf8a6ff3b058cced31336) [2](https://github.com/veraPDF/veraPDF-validation/commit/67ff34fb0369868d83a820f8d32ff5ac55db3830))
- (PDF/UA-2, WTPDF-1) fixed an infinite loop when determining whether an annotation is an Artifact in a document with circular structure-element parent references ([commit](https://github.com/veraPDF/veraPDF-validation/commit/d1a397437ec8a91fd54b36ee361fc4a0616473e4))
- (PDF/UA-1) restored the PDF 1.7 algorithm for determining table header scope in place of the PDF 2.0 algorithm ([commit](https://github.com/veraPDF/veraPDF-validation/commit/6998f6ecc9863aa702f410064d3ed5e0ea0425eb))
- (PDF/A-4) fixed detection of undefined resources when a page has no Resources entry (commits [1](https://github.com/veraPDF/veraPDF-parser/commit/9a5525a84ed3f75bd26e76352777b13649f15aa7) [2](https://github.com/veraPDF/veraPDF-validation/commit/5121a287a99dc15509cbc1b974aec9957be973b5))
- (PDF/A-4) fixed handling of Resources dictionaries in individual Type3 CharProc streams ([commit](https://github.com/veraPDF/veraPDF-validation/commit/2293b248c46e243c46e33006615d71f0a3be7ba0))

### Core library
- fixed JAXB compatibility issues caused by reflective modification of final fields ([commit](https://github.com/veraPDF/veraPDF-library/commit/093031d1741fa9805c325f5f0bf0c31c4b3c6723))
- added `JavaScriptEvaluator.clearScripts()` to clear the current thread's cached scripts and allow associated Rhino classloaders to be reclaimed ([commit](https://github.com/veraPDF/veraPDF-library/commit/8a81a292043a0eeb7892f982d77804e4eadd311a))
- added support for cancelling validation through thread interruption ([commit](https://github.com/veraPDF/veraPDF-library/commit/0247f25567eaf4bdbf02b603953d6ed5a3b73ff0))
- fixed cleanup of temporary log files ([commit](https://github.com/veraPDF/veraPDF-library/commit/60f8f1dc236adb536c3a935488cd6a56a650c941))

### PDF Parser
- fixed parsing of CFF fonts when FontMatrix immediately follows ROS in the Top DICT ([commit](https://github.com/veraPDF/veraPDF-parser/commit/957f8b8d589119ef2b94481cea16ea90dc020cca))
- fixed decryption of documents with R=4 and V=4 when the encryption dictionary has no Length entry ([commit](https://github.com/veraPDF/veraPDF-parser/commit/4d1484e138f2547d4232d196f1f0650c1f58fcb5))
- fixed AES-256 revision 6 password hashing that could incorrectly reject valid passwords ([commit](https://github.com/veraPDF/veraPDF-parser/commit/40ba1b376cb985bb759b79394be1ef96eb44ee8a))
- fixed cleanup of object streams during saveAs ([commit](https://github.com/veraPDF/veraPDF-parser/commit/b2ed039395b2c7618130b77c26d7437deef265a4))
- added configuration of the temporary-file directory and in-memory buffer size ([commit](https://github.com/veraPDF/veraPDF-parser/commit/b0ab310868f29f11499210f8012c8e56ef2666aa))
- added an optional size limit for streams written to temporary files ([commit](https://github.com/veraPDF/veraPDF-parser/commit/0470691c3f866942f901b0661fdf9967fb213bb7))
- added an optional limit on the number of indirect objects in a document ([commit](https://github.com/veraPDF/veraPDF-parser/commit/6225623b49b39e66b87353a378f26eb3d26d5bc0))
- added methods to clear and limit the dynamic PDF-name cache ([commit](https://github.com/veraPDF/veraPDF-parser/commit/3a03b010bb7f9df721e71f2696360888c157676b))
- removed incorrect log messages about missing TrueType cmap tables and invalid use of ICCBased color spaces (commits [1](https://github.com/veraPDF/veraPDF-parser/commit/9c358090763cb1e61a58f207b611a8a184d8ca57) [2](https://github.com/veraPDF/veraPDF-parser/commit/d7ded0ea74b9a9246e4168e6fdd8c694e33df852) [3](https://github.com/veraPDF/veraPDF-validation/commit/8ca1b80ec71cdda77e2877deda0a705e31e9b745))
- added logging for invalid hexadecimal strings in content streams ([commit](https://github.com/veraPDF/veraPDF-validation/commit/6d58ed61f582c0bd77e4078cf39990afd46e4c45))

Version 1.30.2 (June 3, 2026)
=================================

### Security
- added Security policy ([commit](https://github.com/veraPDF/veraPDF-library/commit/f2a6e22ba3fbf6924321d209491c82171ae64fc0))
- fixed vulnerabilities related to unsecure parsing of Rich Text values and XFA forms (commits [1](https://github.com/veraPDF/veraPDF-library/commit/695b44f1d3a38349eb857a8d047923150cd96e2a) [2](https://github.com/veraPDF/veraPDF-validation/commit/cacd9436d0de40b0e58cc7d2dbb06451619e61ec))
- fixed vulnerabilities related to unsecure parsing of PostScript syntax in /ToUnicode CMaps and PS Type1 fonts ([commit](https://github.com/veraPDF/veraPDF-validation/commit/cacd9436d0de40b0e58cc7d2dbb06451619e61ec))

###  Validation
- (PDF/UA-1) fixed missing validation error for the initial use of H (or Hn) structure element if Hn (resp. H) is located later in the document ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/67cf43ede81d0438fb615dcf92baead3b9f3ad67))
- (PDF/UA-2, WTPDF-1) permitted Link and Markup annotations to be Artifacts (commits [1](https://github.com/veraPDF/veraPDF-validation-profiles/commit/1d1e2722960e097aaf187680afd44dff65a2b867) [2](https://github.com/veraPDF/veraPDF-validation-profiles/commit/1d1e2722960e097aaf187680afd44dff65a2b867))

### PDF Parser
- fixed glyph parser in case of a CFF subtable in OpenType ([commit](https://github.com/veraPDF/veraPDF-parser/commit/f0677e25408faea91fad5172e5f43f64051e8e3e))
- fixed the logic of finding alternative description of an annotation ([commit](https://github.com/veraPDF/veraPDF-validation/commit/c8fb5d03f04d20f9d8ee0e6fcfaa74bc344c2cd0))
- fixed Default color space handing in case of Indexed inline images ([commit](https://github.com/veraPDF/veraPDF-parser/commit/862b1f227a184fefeafd959f1e0346b8fde1f9fa))

Version 1.30.1 (April 16, 2026)
=================================

###  Applications
- consistent use of PDF/A part and conformance level capitalization ([commit](https://github.com/veraPDF/veraPDF-apps/commit/78e8c8d2c078df42daa3ce2e9f19dad65781c9af))

###  Validation
- (PDF/UA-1,2, WTPDF-1) permitted top left cells with no Scope in Table structure element ([commit](https://github.com/veraPDF/veraPDF-validation/commit/dfe0dcbcf183b851bf5e419facf85128ce62aeb7))

### PDF Parser
- fixed processing of CID = 0 for symbolic fonts (commits [1](https://github.com/veraPDF/veraPDF-parser/commit/6f78b654e4aff90e4e4ea9d014a348bc10855087) [2](https://github.com/veraPDF/veraPDF-validation/commit/8537c161954340b4c3c06561bc8f26e342ccdc05))

### Metadata fixer
- (PDF/A-4, PDF/UA-2) fixed `rev` value ([commit](https://github.com/veraPDF/veraPDF-validation/commit/e24b45ae6dff5bf8f0b1ad995c83bebcd13829fc))

### Security
- included the fix for [GHSA-72hv-8253-57q](https://github.com/FasterXML/jackson-core/security/advisories/GHSA-72hv-8253-57qq) ([commit](https://github.com/veraPDF/veraPDF-library/commit/06f17c90081f1d3f0f09d81bdde4ebe1c9cd8ae6))

Version 1.30 RC (February 10, 2026)
=================================

###  Applications
- ended PDFBox support
- added new option to install CLI only without GUI ([commit](https://github.com/veraPDF/veraPDF-apps/commit/cf1177a8793c7286e219d50fe947b6357364476e))
- removed sources of validation profiles and the model from the installer ([commit](https://github.com/veraPDF/veraPDF-apps/commit/405f777249d585b3ff150aa52611e093fb2937e5))
- veraPDF Rest API: changed license to MIT ([commit](https://github.com/veraPDF/veraPDF-rest/commit/6eb01dd38cc86c12b7f6ad66994072ce9599cbb0)) and updated dropwizard version to 3.0.16 ([commit](https://github.com/veraPDF/veraPDF-rest/commit/0917c0c2bc9a4231af458e673474f6b595d1da0a))

###  Validation
- (PDF/A-2,3,4, PDF/UA-1,2, WTPDF-1) fixed misprint in three names of predefined CMaps ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/38ec3b6a50233c7e616421b7d61515982413fbce))
- (PDF/A-2,3,4, PDF/UA-1,2, WTPDF-1) relaxed the requirement for the presence of the (3,1) cmap in non-symbolic TrueType fonts in case of a font used solely in rendering mode and no embedded font program (commits [1](https://github.com/veraPDF/veraPDF-validation/commit/a6c4b7f9ed908205b81ccf490efc6770756a4ca8) [2](https://github.com/veraPDF/veraPDF-validation-profiles/commit/f14c0059df4ce82e7778b285b74d2d1546f1a0f5))
- (PDF/A-4, PDF/UA-2) added validation of `pdfaid:rev` and `pdfuaid:rev` ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/44324a8fa55957e626b8df41906d043c174fcc49))
- (PDF/UA-2, WTPDF-1) permit **math** to be not necessarily an immediate child of **Formula** structure element ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/affcbab2f785de738f691b6bd129032e822a863c))
- (PDF/UA-2, WTPDF-1) limited PDF/UA-2 8.10.1 and 8.10.2 clauses to Widget annotations used as appearance of interactive form fields  ([commit](https://github.com/veraPDF/veraPDF-validation-profiles/commit/8779f018fb5ccd96d3d8372d21f10068579f3960))
- (PDF/A) fixed issue with Default ColorSpace not taken into account for the alternate CS of a DeviceN CS of an Image XObject (commits [1](https://github.com/veraPDF/veraPDF-parser/commit/36a43430c0d6c7468262da4b0228c56456002b4d) [2](https://github.com/veraPDF/veraPDF-validation/commit/3f0283f63e60ff24d9da51b16a207634a32425b9))
- (PDF/A-1) fixed matching date validation in case of any of the dates missing in the XMP metadata ([commit](https://github.com/veraPDF/veraPDF-validation/commit/986631569203e7a8833e84ecefd6de25200670ee))

### PDF Parser
- fixed Unicode calculation for Type0 fonts ([commit](https://github.com/veraPDF/veraPDF-parser/commit/c95f61fb3c4f08704602bc49c03fa540af75e950))
- supported the RunLengthDecode filter ([commit](https://github.com/veraPDF/veraPDF-parser/commit/5c5904bf5092db447577bb7554c9e45336f36af3))
- supported the Crypt filter without decode parameters ([commit](https://github.com/veraPDF/veraPDF-parser/commit/ae2f4d84155d0e6fab8769268451d033df1bdb19))
- fixed Runtime exceptions in cases of invalid data structures
- improved logs (commits [1](https://github.com/veraPDF/veraPDF-parser/commit/12a717b7b20fad4af828c0ef66373ea652b47722) [2](https://github.com/veraPDF/veraPDF-parser/commit/6011e0cae3fff14462508bfe7f043d560ecffb41) [3](https://github.com/veraPDF/veraPDF-parser/commit/5f5578f9b3ea881640f780465280d32eda31bbfd) [4](https://github.com/veraPDF/veraPDF-parser/commit/0bb0e840e694f8079c4183d539750cc2146c4bf5))

### Core library
- added support for Java 25
- added automatic module names to the MANIFEST files
- fixed thread safety issues ([commit](https://github.com/veraPDF/veraPDF-library/commit/64aac64cbe1d59d2802488356e736221a1d0f234))
- changed Java interface `parser.getFlavours()` to return empty list instead of a default flavour in case of missing conformance declarations ([commit](https://github.com/veraPDF/veraPDF-validation/commit/7d3c24b7e712649f25969c8de6a41f3c075c9adc))

### Policy Checker
- fixed URI support in XSLT engine ([commit](https://github.com/veraPDF/veraPDF-library/commit/ef2f3fac3e858eb6268dc3de35932d11949a84e4))

Version 1.28.2 (July 15, 2025)
=================================

### Applications
- updated vulnerable dependencies ([commit](https://github.com/veraPDF/veraPDF-library/commit/b75a016))
  
###  Validation
- (PDF/UA-2, WTPDF-1) disabled rule about multiple link annotations that target the same location ([commit](https://github.com/veraPDF/veraPDF-library/commit/3c05a38))
- (PDF/UA-2, WTPDF-1) fixed structure destination validation ([commit](https://github.com/veraPDF/veraPDF-validation/commit/7fe5283))
- fixed validation of Unicode for several flavours ([commit](https://github.com/veraPDF/veraPDF-validation/commit/7d143de))

### PDF Parser
- fixed width calculation in an edge case of Type2CharString ([commit](https://github.com/veraPDF/veraPDF-parser/commit/ea6ba8b))
- fixed COSPredictorDecode (commits [1](https://github.com/veraPDF/veraPDF-parser/commit/e8f9024) [2](https://github.com/veraPDF/veraPDF-parser/commit/703fe86))
- fixed RDF parsing with no attributes in metadata ([commit](https://github.com/veraPDF/veraPDF-library/commit/be2f0fb))
- fixed exceptions in case of malformed PDFs


### Maintenance
- moved Maven publication from the decommissioned Sonatype service to Maven central publication
- added the new maven-central-publication plugin to veraPDF-parent POM for publication for all projects ([commit](https://github.com/veraPDF/veraPDF-parent-pom/commit/16c02dd))
- updated the Maven plugins used to the latest versions ([commit](https://github.com/veraPDF/veraPDF-parent-pom/commit/07e58ea))

Version 1.28 (April 30, 2025)
=================================

###  Applications
- updated izpack to version 5.2.4

###  Validation
- (PDF/UA-1,2, WTPDF-1, ISO 32005) added rules to require Marked=true entry in MarkInfo dictionary
- (PDF/UA-2, WTPDF-1, ISO 32005) fixed parent-child rules for NonStruct, Part and Div
- (PDF/UA-2, WTPDF-1, ISO 32005) fixed exception during table validation in cases of invalid table structure
- (PDF/UA-2, WTPDF-1) fixed mismatch of structure destinations in Link annotations
- (PDF/UA-2, WTPDF-1) fixed rule about alternative text for signature graphic content with no text
- (PDF/UA-2, WTPDF-1) fixed checking ToggleNoView flag for annotations

### PDF Parser
- fixed xref parsing in some exceptional cases and improved error reporting
- fixed parsing of indirect Kids in number tree
- fixed invalid byte range parsing in CMap stream

Version 1.28 RC (February 9, 2025)
=================================

###  Applications
- added validation for several flavours
- created docker image for veraPDF CLI
- added showing location of config

###  Validation
- (WTPDF-1) added support for WTPDF Reuse and Accessibility conformance levels
- (PDF/A, PDF/UA) fixed the issue of accepting sometimes string value type if the PDF specification requires name object type
- (PDF/A) fixed validation of Interpolate entry in image mask dictionaries
- (PDF/A-1) updated the rule on compressed XMP Metadata
- (PDF/UA-1) added rule about PDF version
- (PDF/UA-1) fixed recursive propagation of Artifact to untagged Form XObjects 
- (PDF/UA-1,2) fixed handing of circular role mappings and namespaces
- (PDF/UA-1,2) permitted untagged tilling patterns
- (PDF/UA-2) permitted math structure type only within Formula
- (PDF/UA-2) added rule to require Metadata entry in Catalog
- (ISO 32005) updated Div, Part, NonStruct processing to inherit containment rules from the parent
- (ISO 32005) added containment rules for Ruby and Warichu
- (ISO 32005) permitted Sub as a child of Code
- (ISO 32005) fixed rule on content items in StructTreeRoot

### PDF Parser
- fixed parsing of empty UTF-16 string
- fixed parsing of CFF fonts with empty Name Index
- updated width calculation for CFFType1 font program with duplicated glyph names
- fixed name calculation for glyph with code 0
- fixed signature EOF logic in incremental updates
- fixed parsing of compressed CIDToGIDMap stream

### Core library
- improved performance
- improved logs
- more robust exception handling

### Corpus
- updated PDF/A-4 and PDF/UA-2 test corpus
- added WTPDF declarations to PDF/UA-2 test files

### Documentation
- improved java docs
- improved policy documentation

Version 1.26.2 (December 4, 2024)
=================================

### Applications
- fixed [CVE-2024-52800]

[CVE-2024-52800]: https://github.com/veraPDF/veraPDF-library/security/advisories/GHSA-4cx5-89vm-833x

Version 1.26 (May  16, 2024)
=================================

### Validation
- (PDF/UA-2) supported named structured destinations in goto actions
- (PDF/UA-1) fixed rules about annotations

Version 1.26 RC2 (April 2, 2024)
==================================

### Applications
- set secure parameter for xslt transformation ([CVE-2024-28109])
- improved multithreading performance of JavaScript evaluation

### Core library
- added support for Java 21

### PDF Parser
- fixed MathML parsing exception
- added warning for duplicated MCID in content stream
- fixed CIDFontType2 font program parsing for OpenType fonts
- fixed ROS operator finding for CFF fonts

### Validation
- (PDF/UA-2) include ISO 32005 rules to PDF/UA-2 profile
- (PDF/UA-2) added rule about Ref entry of Note structure element
- (PDF/UA-2) supported validation of Open Action destination
- (PDF/UA-2) disabled ActualText and Alt validation for non-real content
- (PDF/UA-2) fixed checking of role mapping structure types to the same namespace

[CVE-2024-28109]: https://github.com/veraPDF/veraPDF-library/security/advisories/GHSA-qxqf-2mfx-x8jw

Version 1.26 RC (February 9, 2024)
==================================

### Applications
- Improved REST API: more logical endpoints, documentation, web demo page, automatic deployment of the docker image to DockerHub.com
- Redesigned main GUI window
- Improved CLI output (help, debug logs, text report, JSON report formatting)
- Improved XML report schema in case of exceptions
- Fixed GUI check for the availability of a newer version

### PDF Model
- Cleanup of the unused properties and links

### PDF Parser
- Updated predefined CMaps
- Added support for structure attributes defined via ClassMap 
- Fixed parsing of inline images of undefined length
- Detect and generate a warning when dictionary contains duplicated keys
- Detect and generate a warning when the embedded font has duplicated glyph names
- Detect and generate a warning in case of loops in document structure tree
- Fixed decryption of string objects
- Fix default whitepoint for CIELab in JPEG2000
- Optimized use of temporary files

### Validation
- (PDF/UA-2) added support for PDF/UA-2 (draft)
- (PDF/UA-1) detect and report structure elements with missing parent
- (PDF/UA-1) fixed checks related to role maps between standard and non-standard tags
- (PDF/UA-1) fixed rules related to annotations in structure tree
- (PDF/UA-1) added checks for XMP prefixes in the identification metadata
- (PDF/A-1,2,3,4) added check for valid values of BitsPerComponent
- (PDF/A-2,3,4) apply the rule on identical tint transform also to /All and /None
- (PDF/A-1) added check that the document does not use xref stream
- (PDF/A-1) Fix syncing XMP with Info dictionary in case of multiple creators

Version 1.24 RC2 (June 2, 2023)
==================================

### PDF model
- added a new property XMPCreatorSize for the number of creators

### PDF Parser
-  fixes of unhandled exceptions in malicious PDFs
-  fix of the CIDSet parsing for embedded OpenType fonts
-  updated regex for PDF Date to support border cases
-  added warning in case of invalid Version entry in the catalog
-  fixed an issue of accepting String value types where Name type is required and vice versa

### Validation
-  (PDF/A-1) fixed comparison of Info dictionary Author and XMP dc:creator in case of multiple authors/creators
-  (PDF/A-2,3,4) fixed handling of Default color spaces for DeviceN colorants
-  (PDF/UA-1) reverted Table Scope determination algorithm from PDF 2.0 to PDF 1.7


Version 1.24 RC (April 27, 2023)
==================================

### Applications
- added support for recursive processing of PDF files in ZIP archives
- revised and upgraded plug-ins included into the installation bundle
- added Cancel button in GUI to cancel the job
- added new `--progress` parameter in CLI to report progress info
- added new `--config` parameter in CLI to support config file as a new CLI argument
- renamed `xml` report format option to `raw` in CLI (`xml` is now reserved for the default report format)
- enhanced validation error messages and their variable data
- support feature report in json format
- added warnings on incompatible CLI arguments
- fixed saving GUI application settings
- fixed getting log level from the config file
- fixed handling of malformed config files

### PDF model

- added new property `nestingLevel` to Hn structure element
- added new properties `firstPageIDValue` and `lastIDValue` to `COSDocument`
- refactored the properties of XMP and Info dictionary metadata
- refactored the properties for Table structure elements

### PDF Parser
- added method to check for an ascii-string
- updated predefined CMaps
- fixed parsing hybrid PDFs
- fixed decoding Flate filters with invalid checksum
- fixed issue with duplicated short and long keys in inline image dictionaries
- added warning for Page objects with missing resources dictionary
- added support for PDF 2.0 namespace and PDF 2.0 standard structure elements  

### Validation
- (PDF/UA-1) fixed validating TU entry in form fields with multiple Widget annotations
- (PDF/UA-1) refactored Table validation rules
- (PDF/UA-1) added a new rule to check for presence of StructTreeRoot entry in the document catalog
- (PDF/A-2,3,4) fixed issue with false negative for CMYK-based JPEG2000 images in presence of DefaultCMYK color space
- (PDF/A-1,2,3,4) refactored and enchanced metadata fixer functionality
- (PDF/A-2,3,4) permit empty Name for the optional content configuration dictionary  
- (PDF/A-2,3,4) fixed validation of circular role mapping
- (PDF/A-1,2,3) updated rules ids to match the exact location of the corresponding "shall" clause in the specification

### Core library
- added support for jakarta and Spring Boot 3 (Java 11+ only)
- fixed output encoding of all logs and reports to be UTF8 (independently of locale)


Version 1.22 RC (August 3, 2022)
==================================

### Applications
- added HTML and JSON report formats in the CLI app
- fixed CLI scripts for Windows to support arbitrary characters in the veraPDF installation folder
- fixed file drag&drop functionality for the GUI app on MacOS
- force mrr report format if policy checks are enabled
- added support for user specific config directory
- added option to include all warnings into the validation report (both GUI and CLI)
- added verbosity level to CLI app to control the level of visible warnings
- exit after displaying help message if CLI is invoked without parameters
- fixed check for veraPDF updates from the GUI app

### PDF Model
- added support for evaluating PDF functions
- added support for PDF 2.0 namespace mechanism
- added support for standard structure types in PDF 2.0 namespace

### PDF Parser
- improved CFF font parsing: trim the CharSet range by the number of glyphs specified in the other font data
- implemented greenfield parser for PKCS #7 files
- added support for custom font matrices in CFF fonts
- implemented more tolerant Flate decode with broken checksum
- added warning for UTF16-LE encoded text string

### Validation
- (PDF/UA-1) added a new rule that the Form structure element without Role attribute shall have only one child: an object
reference identifying the widget (ISO 32000-1, Table 348)
- (PDF/A-4) updated supplement numbers for predefined character collections and CMaps 
- (PDF/A-2,3,4) added a check if a character in a symbolic TrueType font cannot be mapped to a font glyph via the specified algorithms
- (PDF/A-2,3,4) do not require the presence of CIDtoGID map for CIDType2 fonts without embedded font program, which are used solely in rendering mode 3
- revised error messages with additional context parameters 

### Corpus
- automated regression tests 

### Core library
- added support for Java 17
- added support for Java Platform Module System (JPMS)

**CAUTION**: the JPMS support required moving several classes into different packages:

- `org.verapdf.pdfa.PdfBoxFoundry` -> `org.verapdf.pdfbox.foundry.PdfBoxFoundry`
- `org.verapdf.pdfa.PdfBoxFoundryProvider` -> `org.verapdf.pdfbox.foundry.PdfBoxFoundryProvider`
- `org.verapdf.pdfa.VeraFoundry` -> `org.verapdf.gf.foundry.VeraFoundry`
- `org.verapdf.pdfa.VeraGreenfieldFoundryProvider` -> `org.verapdf.gf.foundry/VeraGreenfieldFoundryProvider`

These changes need to be applied to any Java source code that integrates veraPDF API as a Java library. 

Version 1.20 RC (December 2, 2021)
==================================

### Applications
- added support for PDF/A-4 including Level F (file attachments) and Level E (engineering)
- added more informative logs in batch processing
- added new parameter to specify the default validation profile in case of missing standard identification in XMP Metadata

### PDF Model
- extended the model to support PDF/A-4 rules

### PDF Parser
- more robust handling of malicious PDF documents
- improved parsing of PostScript and CFF fonts

### Validation
- allow empty Lang Alt arrays in XMP metadata
- excluded All and None colorants from the PDF/A-2 and PDF/A-3 requirement to have the same tintTransform and alternateSpace
- disabled JPEG2000 `colr` box checks in case of explicitly defined ColorSpace in the Image dictionary
- fixed validation of predefined XMP value types if they are redefined in the extension schema
- validate XMP URL type as Text
- fixed CIDSet and CharSet validation for PDF/A-1
- fixed validation of the permissions dictionary in PDF/A-2 and PDF/A-3
- added validation of Lang against RFC 1766 regular expression
- fixed validation of permitted transfer functions in Halftone dictionaries

### Corpus
- added test corpus of ~600 new atomic documents covering PDF/A-4 specification
- extended PDF/A-2u tests on ToUnicode mapping and character encodings in simple fonts

### Core library
- added support of Java versions from 11 to 16
- fixed validation of documents with non-PDF extension in multi-process mode

Version 1.18 (February 23, 2021)
=================================

### Applications
- added support for PDF/UA-1 (Machine) validation
- fixed issues with STDIN support
- added support for input files with non-pdf extension

### PDF Model
- extended the model to support PDF/UA-1 rules

### PDF Parser
- fixed parsing of inline images
- fixed token parsing on non-ASCII systems
- fixed TrueType font parsing in case of different number of glyphs specified in maxp and post tables
- fixed infinite loop in circular dependency of CMaps
- added support for documents with zero pages
- improved parsing of Type1 font private data
- improved glyph width calculation for CFF fonts
- fixed null pointer exceptions on invalid PDF documents (multiple places)

### Core library
- adjusted validation reports to support PDF/UA-1 profile 


Version 1.16 (February 19, 2020)
=================================
### Applications
- added drag&drop support for input files in the GUI

### PDF Model
- added PDFunction type to support validation of Type4 functions
- added types corresponding to the PDF 1.7 standard structure tagset
- added actualEncoding property of XMP Metadata

### PDF Parser
- fixed null pointer exception on empty trailer
- improved the logic of parsing page content consisting of multiple streams

### Core library
- improved memory management in case of large number of validation errors


Version 1.14 (June 10, 2019)
==============================

### Applications
- fixed installer CLI args not forwarded [[#apps-253][]], [[#iss-1021][]]
- fixed Java 11 XML bind dependencies [[#apps-254][]], [[#iss-986][]]
- command line application termination codes [[#apps-255][]], [[#apps-256][]], [[#iss-841][]]

## PDF Model:
- added processColor link for PDDeviceN [[#mod-168][]], [[#iss-902][]]

## PDF Parser:
- fixed XRefStream handling for trailers [[#par-359][]]
- fixed space skipping after RD for type1 [[#par-360][]], [[#par-361][]]
- fixed various issues with AES decryption [[#par-362][]], [[#par-364][]], [[#par-365][]]
- fixed font encoding issue [[#par-363][]]
- fixed buffered in filter and COSStream problems [[#par-366][]]
- fixed SOF exception for colorspaces [[#par-368][]]
- fixed date parser issue [[#par-368][]]
- fixed creation of PD resources from dictionary when cos object empty  [[#par-370][]]
- logging improvements [[#par-367][]], [[#par-371][]]
- fixed toUnicode for PDF/A-1 glyph name check [[#par-372][]], [[#iss-1012][]]
- add underlying color space for PDPattern [[#par-373][]], [[#iss-984][]]

## Core Library:
- fixed xmp-core byte buffer [[#lib-974][]]
- logging improvements [[#lib-980][]], [[#lib-1023][]]
- input stream and file processing XML results now consistent [[#lib-1020][]], [[#iss-1014][]]
- fixed Java 11 XML bind dependencies  [[#lib-1022][]], [[#iss-986][]]
- performance tweaks  [[#lib-1028][]]

## PDF Validation:
- fix metadata creation [[#val-270][]]
- fix null pointer exception when processing glyphs [[#val-271][]]
- fix null pointer exception when validating embedded files [[#val-273][]], [[#iss-976][]]
- fixed graphic state initial colorspace creation and font inheritance  [[#val-274][]], [[#iss-975][]], [[#iss-978][]]
- deny operators q, Q, cm inside Text object [[#val-276][]], [[#iss-985][]]
- preflight passes, veraPDF shows clause="6.2.11.4" error [[#val-277][]], [[#iss-1019][]]
- fix Ignore trailing zero for info dictionary values during metadata info match xmp check [[#val-278][]], [[#iss-1017][]]
- fixed Java 11 XML bind dependencies  [[#val-279][]], [[#iss-986][]]
- fix processColorspace model link implementation for PDDeviceN [[#val-280][]], [[#iss-902][]]
- added warning for invalid color space objects [[#val-281][]], [[#iss-797][]]
- fix process color operator flag logic, add underlying color space processing for PDPattern [[#val-282][]], [[#iss-984][]]

## PDF Box Validation:
- fix metadata creation [[#pdf-195][]]
- fixed Java 11 XML bind dependencies  [[#pdf-197][]], [[#iss-986][]]
- fix processColorspace model link implementation for PDDeviceN [[#pdf-198][]], [[#iss-902][]]

[#iss-797]: https://github.com/veraPDF/veraPDF-library/issues/797
[#iss-841]: https://github.com/veraPDF/veraPDF-library/issues/841
[#iss-902]: https://github.com/veraPDF/veraPDF-library/issues/902
[#iss-975]: https://github.com/veraPDF/veraPDF-library/issues/975
[#iss-976]: https://github.com/veraPDF/veraPDF-library/issues/976
[#iss-978]: https://github.com/veraPDF/veraPDF-library/issues/978
[#iss-984]: https://github.com/veraPDF/veraPDF-library/issues/984
[#iss-985]: https://github.com/veraPDF/veraPDF-library/issues/985
[#iss-986]: https://github.com/veraPDF/veraPDF-library/issues/986
[#iss-1012]: https://github.com/veraPDF/veraPDF-library/issues/1012
[#iss-1014]: https://github.com/veraPDF/veraPDF-library/issues/1014
[#iss-1017]: https://github.com/veraPDF/veraPDF-library/issues/1017
[#iss-1019]: https://github.com/veraPDF/veraPDF-library/issues/1019
[#iss-1021]: https://github.com/veraPDF/veraPDF-library/issues/1021

[#apps-253]: https://github.com/veraPDF/veraPDF-apps/pull/253
[#apps-254]: https://github.com/veraPDF/veraPDF-apps/pull/254
[#apps-255]: https://github.com/veraPDF/veraPDF-apps/pull/255
[#apps-256]: https://github.com/veraPDF/veraPDF-apps/pull/256

[#lib-974]: https://github.com/veraPDF/veraPDF-library/pull/974
[#lib-980]: https://github.com/veraPDF/veraPDF-library/pull/980
[#lib-1020]: https://github.com/veraPDF/veraPDF-library/pull/1020
[#lib-1022]: https://github.com/veraPDF/veraPDF-library/pull/1022
[#lib-1023]: https://github.com/veraPDF/veraPDF-library/pull/1023
[#lib-1028]: https://github.com/veraPDF/veraPDF-library/pull/1028

[#mod-168]: https://github.com/veraPDF/veraPDF-model/pull/168

[#par-359]: https://github.com/veraPDF/veraPDF-parser/pull/359
[#par-360]: https://github.com/veraPDF/veraPDF-parser/pull/360
[#par-361]: https://github.com/veraPDF/veraPDF-parser/pull/361
[#par-362]: https://github.com/veraPDF/veraPDF-parser/pull/362
[#par-363]: https://github.com/veraPDF/veraPDF-parser/pull/363
[#par-364]: https://github.com/veraPDF/veraPDF-parser/pull/364
[#par-365]: https://github.com/veraPDF/veraPDF-parser/pull/365
[#par-366]: https://github.com/veraPDF/veraPDF-parser/pull/366
[#par-367]: https://github.com/veraPDF/veraPDF-parser/pull/367
[#par-368]: https://github.com/veraPDF/veraPDF-parser/pull/368
[#par-370]: https://github.com/veraPDF/veraPDF-parser/pull/370
[#par-371]: https://github.com/veraPDF/veraPDF-parser/pull/371
[#par-372]: https://github.com/veraPDF/veraPDF-parser/pull/372
[#par-373]: https://github.com/veraPDF/veraPDF-parser/pull/373

[#pdf-195]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/195
[#pdf-197]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/197
[#pdf-198]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/198

[#val-270]: https://github.com/veraPDF/veraPDF-validation/pull/270
[#val-271]: https://github.com/veraPDF/veraPDF-validation/pull/271
[#val-273]: https://github.com/veraPDF/veraPDF-validation/pull/273
[#val-274]: https://github.com/veraPDF/veraPDF-validation/pull/274
[#val-276]: https://github.com/veraPDF/veraPDF-validation/pull/276
[#val-277]: https://github.com/veraPDF/veraPDF-validation/pull/277
[#val-278]: https://github.com/veraPDF/veraPDF-validation/pull/278
[#val-279]: https://github.com/veraPDF/veraPDF-validation/pull/279
[#val-280]: https://github.com/veraPDF/veraPDF-validation/pull/280
[#val-281]: https://github.com/veraPDF/veraPDF-validation/pull/281
[#val-282]: https://github.com/veraPDF/veraPDF-validation/pull/282

Version 1.12 (May 9, 2018)
==========================

## PDF Parser:
- added support for PDF files over 2Gb [[#par-334][]]
- fixed date parsing issues with trailing apostrophe [[#par-335][]]
- fixed bug with Standard Encoding in PostScript font programs [[#par-340][]]
- fixed issue parsing digital signatures for files below 1024 bytes [[#par-343][]], [[#par-351][]], [[#par-353][]]
- fixed issue with recognition of standard font with differences entry and parsing empty differences array [[#par-345][]][[#par-350][]]
- close streams properly during parsing and ensure tempfile deletion [[#par-346][]], [[#par-352][]], [[#par-353][]]
- fixed signature EOF stream logic causing ByteRange issues[[#par-348][]]
- Fixed detection of the CFF font charset in case of a predefined charset with incomplete glyph plus issues with Adobe Type 3 Font, Adobe Type 1 Font and ASCII85 parsing [[#par-348][]], [[#par-355][]]
- added check to disallow and report Type 1 PFB fonts [[#par-349][]]

## Conformance Checker:
- add Identifier to validator type for reporting, added details to HTML report [[#val-261][]], [[#lib-940][]]
- fixed issue parsing digital signatures for files below 1024 bytes [[#val-265][]]
- exclude process colors from spot color validation in DeviceN / NChannel color spaces for PDF/A-2 and 3 [[#val-267][]] [[#pdf-191][]]
- fixed metadata extensions support across different PDF/A levels [[#lib-947][]]
- fixed bug with automatic selection and processing of PDF/A flavour  [[#pdf-190][]]
- fixed validation of smooth shading color spaces and inline images in presence of default color space [[#val-263][]]
- fixed bug in embedded file features data extraction [[#lib-951][]]
- fixed bug with validation rule caching [[#lib-963][]]

## Application enhancements:
- added fixes for thread safety and multithreading support [[#apps-246][]], [[#apps-248][]], [[#par-342][]], [[#lib-941][]], [[#lib-960][]], [[#val-262][]],  [[#pdf-189][]], [[#lib-950][]] [[#apps-244][]]
- added multi-process parallelization in the CLI [[#apps-242][]]
- improved formatting of XML reports [[#apps-243][]]
- fixed plug-ins loading mechanism [[#apps-244][]]
- updated copyright statement for GUI  [[#apps-245][]]

## Project infrastructure
- merged veraPDF-xmp project with library [[#lib-964][]]

[#lib-940]: https://github.com/veraPDF/veraPDF-library/pull/940/
[#lib-941]: https://github.com/veraPDF/veraPDF-library/pull/941/
[#lib-947]: https://github.com/veraPDF/veraPDF-library/pull/947/
[#lib-950]: https://github.com/veraPDF/veraPDF-library/pull/950/
[#lib-951]: https://github.com/veraPDF/veraPDF-library/pull/951/
[#lib-960]: https://github.com/veraPDF/veraPDF-library/pull/960/
[#lib-963]: https://github.com/veraPDF/veraPDF-library/pull/963/
[#lib-964]: https://github.com/veraPDF/veraPDF-library/pull/964/

[#par-334]: https://github.com/veraPDF/veraPDF-parser/pull/334/
[#par-335]: https://github.com/veraPDF/veraPDF-parser/pull/335/
[#par-340]: https://github.com/veraPDF/veraPDF-parser/pull/340/
[#par-342]: https://github.com/veraPDF/veraPDF-parser/pull/342/
[#par-343]: https://github.com/veraPDF/veraPDF-parser/pull/343/
[#par-345]: https://github.com/veraPDF/veraPDF-parser/pull/345/
[#par-346]: https://github.com/veraPDF/veraPDF-parser/pull/346/
[#par-347]: https://github.com/veraPDF/veraPDF-parser/pull/347/
[#par-348]: https://github.com/veraPDF/veraPDF-parser/pull/348/
[#par-349]: https://github.com/veraPDF/veraPDF-parser/pull/349/
[#par-350]: https://github.com/veraPDF/veraPDF-parser/pull/350/
[#par-351]: https://github.com/veraPDF/veraPDF-parser/pull/351/
[#par-352]: https://github.com/veraPDF/veraPDF-parser/pull/352/
[#par-353]: https://github.com/veraPDF/veraPDF-parser/pull/353/
[#par-355]: https://github.com/veraPDF/veraPDF-parser/pull/355/

[#val-261]: https://github.com/veraPDF/veraPDF-validation/pull/261/
[#val-262]: https://github.com/veraPDF/veraPDF-validation/pull/262/
[#val-263]: https://github.com/veraPDF/veraPDF-validation/pull/263/
[#val-265]: https://github.com/veraPDF/veraPDF-validation/pull/265/
[#val-267]: https://github.com/veraPDF/veraPDF-validation/pull/267/

[#pdf-188]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/189/
[#pdf-189]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/189/
[#pdf-190]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/190/
[#pdf-191]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/191/
[#pdf-192]: https://github.com/veraPDF/veraPDF-pdfbox-validation/pull/192/

[#apps-242]: https://github.com/veraPDF/veraPDF-apps/pull/242/
[#apps-243]: https://github.com/veraPDF/veraPDF-apps/pull/243/
[#apps-244]: https://github.com/veraPDF/veraPDF-apps/pull/244/
[#apps-245]: https://github.com/veraPDF/veraPDF-apps/pull/245/
[#apps-246]: https://github.com/veraPDF/veraPDF-apps/pull/246/
[#apps-248]: https://github.com/veraPDF/veraPDF-apps/pull/248/

Version 1.10 (November 30, 2017)
==========================

## PDF Parser:
- fixed retrieval of glyph widths from PS and CFF font programs (multiple issues);
- optimized creation and cleanup of temporary files; and
- optimized parsing of text-related data in PDF documents (up to 3 times faster for PDF documents with primarily text content).

## Conformance Checker:
- fixed checks on the presence of SMask, NeedAppearances keys in case of invalid value types;
- fixed ByteRange check of digital signatures in case of incrementally updated files;
- fixed Unicode checks in PDF/A-1A validation for Type1 and Type3 fonts;
- fixed inheritance of /FT entry in Widget annotations; and
- fixed role map retrieval in case of remapping standard structure types.

## Policy Checker:
- fixed Schematron warnings in Policy checks; and
- fixed issue with access to temp reports from Schematron stylesheets on some systems and in case of Java 9.

## Application enhancements:
- fixed various issues caused by Java 9, particularly a problem in the start up scripts; and
- fixed access to PDF resources in case of veraPDF integration into web applications.


Version 1.8 (August 9, 2017)
==========================

## PDF parser:
- fixed PS-specific issues in parsing embedded CMaps, ToUnicode maps and PS Type1 fonts;
- implemented the protection against (invalid) loops in PDF tree structures;
- fixed parsing of CIDSet and CharSet and their comparison with the glyph collection in the embedded font subset (PDF/A-2 and PDF/A-3);
- implemented support for CalCMYK colour space as specified in ISO 32000-1; and
- fixed initialization and inheritance of graphics state for tiling patterns, Type3 fonts and form XObjects.

## Conformance checker:
- implemented check for glyph width consistence in case of Type3 fonts;
- implemented check for the Private Unicode Area use in Level A conformance;
- implemented validation of transfer functions in Halftone dictionaries (PDF/A-2 and PDF/A-3);
- added validation of MIME type value for embedded files (PDF/A-3);
- refactored the validation model to check for presence of certain keys, even if they refer to empty arrays/collections;
- fixed misspelled predefined CMap names for GBK2K-H and GBK2K-V;
- fixed validation of UTF8 encoding for role map names (PDF/A-2 and PDF/A-3); and
- fixed detection of references to Associated files from marked content sequences (PDF/A-3)

## Feature report generation and policy checker:
- added new features to the report:
  * PDF Version;
  * form field names and values; and
  * page labels.

## Application enhancements:
- implemented automatic configuration of veraPDF feature report by a custom Policy profile;
- implemented workaround for the veraPDF GUI appearance on high resolution screens;
- fixed problems with spaces if full JRE path used on Windows; and
- fixed problems handling spaces in installer path.

## Infrastructure:
- implemented automatic generation of PREFORMA test reports; and
- both greenfield anb PDF Box versions now built and packaged from a single branch

## Test corpus:
- fixed veraPDF test files to comply with PDFA TechNote 0010; and
- fixed outlines Count value to comply with ISO 32000-1

# Version 1.6 (June 6, 2017)

## Desktop Applications:
- GUI and CLI now capable of checking for updated version of the software.

## Conformance Checker:
Updated validation logic to comply with Technical Working Group resolutions:
- color spaces are validated now when specified in the content stream;
- a CMap may refer only to predefined CMaps in the ‘usecmap’ operator; and
- OpenType causes an ‘unsupported font type’ error in PDF/A-1 validation.

Other conformance checker fixes and improvements:
- fixed calculation of glyph widths for embedded CFF fonts in some special cases;
- fixed validation of digital signature ByteRange array;
- fixed recursive links of color spaces;
- fixed validation of spaces in the indirect object header;
- fixed Crypt filter handling;
- fixed misprint in ‘Lbl’ structure tag; and
- added support for glyphs with CIDs > 65535 (with an appropriate validation. error)

## Policy checker:
- fixed feature extraction from encrypted documents.

## Test corpus:
- added new test corpus for the Technical Working Group resolutions;
- fixed test file for digital signature validation; and
- fixed test files for Extension Schema definitions in XMP.

# Version 1.4 (April 20, 2017)

## Conformance Checker:
- significant optimization of performance in the greenfield PDF parser
- fixed parsing of embedded PS Type1 fonts
- fixed default value of WMode entry for embedded CMaps
- fixed inline image data parsing
- fixed digital signature parsing

## Reporting:
- refactored feature extraction
- pretty formatted XML reports
- clearer XML structure in veraPDF reports
- improvements to the HTML reports

## Policy Checker:
- added GUI wizard for creating custom policy files

## Infrastructure
- release artifacts now deployed to Maven Central
- started transfer to external static code QA service

## Test corpus:
- aligned the existing veraPDF corpus and added 80 new test files to cover Technical Working Group resolutions

# Version 1.2 (March 2, 2017)
PDFBox version downloadable from http://downloads.verapdf.org/rel/verapdf-installer.zip. Greenfield version downloadable from: http://downloads.verapdf.org/gf/verapdf-gf-installer.zip.

This is a maintenance release focused on bug fixing and improvements of the test infrastructure.

## Conformance checker:
- fixed cache issues in parsing embedded CMaps
- fixed multiple issues with glyph widths checks for embedded CID fonts
- fixed CIDSet entry validation
- fixed delimiter handling in parsing content streams
- ignore None colorants when checking DeviceN color spaces
- fixed validation of Order arrays in optional content groups
- fixed parsing of /ToUnicode map

## Policy checker:
- fixed plug-in infrastructure
- fixed handling of unknown feature types
- added error info into HTML reports in case of broken PDFs

## Documentation:
- updated developer samples
- updated GUI documentation

# Version 1.0 (January 9, 2017)
PDFBox version downloadable from http://downloads.verapdf.org/rel/verapdf-installer.zip. Greenfield version downloadable from: http://downloads.verapdf.org/gf/verapdf-gf-installer.zip.

## Application enhancements:
- fixed default values for extracted PDF features; and
- fixed removal of temporary files.

## Conformance checker:
- fixed cmap table parsing in TrueType fonts.

## Test corpus:
- changed Metadata File provenance test files from fail to pass (as discussed at the validation technical working group); and
- fixed xref table in test case 6-3-3-t01-pass-a.

# Version 0.28 (December 20, 2016)
Last pre-version 1.0 release. PDFBox version downloadable from http://downloads.verapdf.org/rel/verapdf-installer.zip. Greenfield version downloadable from: http://downloads.verapdf.org/gf/verapdf-gf-installer.zip.

## Application Enhancements
- schematron based policy checker implementation:
  * Example policy schemas on GitHub https://github.com/veraPDF/veraPDF-policy-docs/tree/master/Schemas; and
  * policy functionality available in CLI and GUI;
- greenfield implementation of feature extraction;
- greenfield implementation of metadata fixer;
- GUI now supports checking multiple files or a directory;
- HTML summary report for multiple file results;
- single file detailed report containing policy and feature information; and
- stability improvements and performance optimization of the Greenfield parser.

## Conformance checker
- fixed glyph width checks in case of exactly 1/1000 point difference;
- fixed default color space processing for Indexed color spaces;
- fixed Order array support for OCG checks in PDF/A-2; and
- fixed Unicode character maps support for PDF/A-1 Level A.

# Version 0.26 (November 16, 2016)
We've made two downloads available for out 0.26 release. There's the usual version, based on Apache PDFBox and downloadable from: http://downloads.verapdf.org/rel/verapdf-installer.zip. For 0.26 we've also prepared the first beta release of our purpose built PDF parser and validation model, also known as the greenfield validator. This is downloadable from: http://downloads.verapdf.org/gf/verapdf-gf-installer.zip. It's not functionally complete yet as it only supports PDF/A validation. Full details of the release features are listed below.

## Conformance checker
- added the new rule for embedded files to be associated with the document or its parts (PDF/A-3 only).

## Application enhancements
- first beta release of greenfield PDF/A validation available as a limited functionality app;
- refactoring of sub-component and application configuration for reproducible execution;
- new BatchProcessor producing multi-item reports;
- batch processing is stream/event driven with event handlers for processing results; and
- report structures altered to accommodate batch processing.

## Code Quality
- publication of integration tests for Greenfield components;
- memory usage and execution times in test reports;
- example test report available here at time of writing: http://tests.verapdf.org/0.26.8/

## Test corpus
- added 7 new test files to cover the new rule in PDF/A-3 validation profile

## Disabled functionality
In order to accommodate batch reporting for this release we've had to sacrifice
redirecting output to user files. This isn't permanent and will be re-instated for the next release. The following functionality has been temporarily disabled:

### Standard release
- HTML report from CLI, HTML reporting will be a function of the dedicated reporter in the next release. HTML reports are still available from the GUI;
- the -pw option that allows the user to override the profiles wiki, this was only used to generate the HTML report so is not required;
- the -c load config option, config is automatically loaded from the app area and we're adding user config to the next release;
- the --reportfile, --reportfolder, and --overwriteReportFile as these need a rethink to accommodate batch processing.

### Greenfield release
The Greenfield release is missing all of the above plus:
- metadata fixing in GUI and CLI; and
- feature extraction in GUI and CLI.

# Version 0.24 (October 11, 2016)

## Conformance checker
- added extraction of the AFRelationship key for embedded files as a part of veraPDF feature extraction.

## Application enhancements
- implemented prototype of batch validation from CLI and GUI;
- implemented robust handling of run-time exceptions during batch processing; and
- added error info on the run-time exceptions to the validation report.

## Code Quality
- moved feature extraction and metadata fixing code to library; and
- tidied various compiler warnings.

# Version 0.22 (September 7, 2016)

## Application enhancements:
- changed default feature generation to document level features
- added a new GUI dialog for managing feature generation options
- added a user-friendly Java OutOfMemoryError with suggestions for reconfiguration
- CLI can now overwrite report files
- added help message when CLI processes STDIN stream
- synchronized the Web demo validation report with the CLI and GUI report styles

## Conformance checker fixes:
- removed the rules for validating file provenance information (based on veraPDF TWG discussion)
- fixed an issue with structure type mapping in Level A validation
- implemented resource caching for memory optimization

## Test corpus:
- converted all 'fail' test cases on file provenance information to 'pass' tests

# Version 0.20 (August 1, 2016)

## Application enhancements:
- added signature types to features report;
- depth of feature reporting now configurable; and
- altered log level of some validation methods.

## Conformance checker fixes:
- fix for validation of character encoding requirements of invisible fonts; and
- fix for ICC Profile mluc tag.

## Test corpus:
- 34 new test files for PDF/A-2b.

# Version 0.18 (July 5, 2016)

This beta release provides fixes for PDF/A Validation, enhanced functionality & usability fixes for the application, and additions to the test corpus. It also marks the launch of our beta documentation site.

## Application enhancements:
- suppress all PDFBox warnings in the CLI interface when parsing PDF documents
- generate error report instead of the exception in case of broken PDF documents
- added a new CLI option to save XML report to a separate file in recursive PDF processing

## veraPDF characterisation plugins
  - enhancements to example pure java plugins available
  - plugins now configurable through dedicated config file

## Conformance checker fixes:
- ignore DeviceGray color space in soft mask images
- treat glyph with GID 0 as “.notdef” in case of Type0 fonts
- fixed validation of role map for non-standard structure elements (Level A)
- fixed validation of page size implementation limits in case of negative width or height
- fixed validation of non-standard embedded CMaps referenced from other CMaps

## Test corpus:
- added 180 new test files for parts 2 and 3

## Infrastructure
- test coverage now monitored by Codecov online service
- integration tests for 2u and 3b validation profiles added
- using codacy and coverity online code QA services

# Version 0.16 (June 3, 2016)

This beta release features the full support of all PDF/A-2 and PDF/A-3 requirements (all levels). Together with earlier support of PDF/A-1 validation, it represents the first full support for all PDF/A parts and conformance levels.

## Features
- Conformance checker
  - added validation of digital signature requirements
  - added extraction of color space info from JPEG2000 images
  - added validation of permissions dictionary (Parts 2 and 3)
  - PDF/A-2B fix: correct implementation of CIDSystemInfo entry requirements
  - command line support for plugin execution to extend feature extraction

## veraPDF characterisation plugins
  - first set of example pure java plugins available
  - optional sample plugin pack available through installer

## Test corpus:
  - Added further 112 atomic test files for parts 2 and 3

## Infrastructure:
  - added support for all parts and conformance levels at http://demo.verapdf.org


# Version 0.14 (May 5, 2016)

This beta release features Transparency and Unicode character map validation in
PDF/A-2 levels B and U.

## Features
- Conformance checker:
  - added all transparency-related validation rules in PDF/A-2 and PDF/A-3
  - added full Level U support in PDF/A-2 and PDF/A-3
  - code refactoring to synchronize GUI, API and CLI interfaces
  - PDF/A-1B fix: check both Tiling patterns used as different fill and stroke
    colour spaces in the same drawing operations
  - added initial versions of PDF/A-2U, PDF/A-2A, PDF/A-3U, PDF/A-3A validation
    profiles. We now have initial validation for all PDF/A flavours.

## Test corpus:
  - added a further 65 atomic test files for PDF/A-2 specific requirements

## Infrastructure:
  - a demo of the REST interface is available at http://demo.verapdf.org

# Version 0.12 (March 31, 2016)

This beta release features improved PDF/A-2b and PDF/A-3b validation and the fully featured REST API.

## Features
- Conformance checker:
  - PDF/A-2 and PDF-A/3 improvements: implement checks for optional content, JPEG2000 requirements
  - full compliance with BFO test suite (PDF/A-2b)
  - PDF/A-1b fix: check for form field appearance
  - code refactoring to enable PDF model implementation via different PDF parsers
  - performance and memory optimization

- Test corpus:
  - full coverage of all predefined XMP properties

- Documentation
  - first version of wiki on all validation rules available at: https://github.com/veraPDF/veraPDF-validation-profiles/wiki

- Command line:
  - CLI now supports metadata fixing

- Infrastructure
  - veraPDF-library project refactored into multiple projects.
  - PDF Box validator implementation in separate project.
  - Automated source packaging with dependencies.

# Version 0.10 (February 29, 2016)

This beta release features command line interface enhancements

## Features
- Conformance checker:
 - new implementation of the XMP validation
 - proper CharSet / CIDSet validation

- Command line:
 - processes stdin if no file paths are supplied for use in *nix pipes;
 - directory and recursive sub-directory processing; and
 - text mode output with summarised output

- Test corpus:
 - initial set of PDF/A-2 test files

## Fixes
- Conformance checker:
 - fixed CMap / WMode validation
 - minor fixes in PDF/A-2b and PDF/A-3b validation profiles
 - based on TWG resolution, fixed validation normal appearance object type (Dict vs Stream) for Button widgets

- Command line fixes:
 - all CLI output for a single file now in one XML document; and
 - error output now all to stderr, keeping stdin clean;

***

# Version 0.8 (December 22 2015)

This beta release features a command line interface for validation and feature extraction, with supporting install scripts.

## Features

- Refactored plug-in architecture.
- Re-designed command line interface for PDF/A validation and feature reporting.
- Updated validation profile syntax.
- Simplified machine-readable report format.
- Bug fixes for:
 - comparison of Info dictionary and XMP metadata (PDF/A-1);
 - support for missing resources and resource inheritance mechanism (PDF/A-1); and
 - parsing TrueType fonts with zero-length tables.
- Synchronization with PDFBox 2.0 RC1 library.

## Infrastructure

- Installer adds command line scripts.
- Refactored integration tests.

## Test corpus

***

# Version 0.6 (October 30, 2015)

This beta release includes a fully functional, internally-tested implementation for complete PDF/A-1b validation, PDF Feature Report generation, and the Metadata Fixer.

## Features

- Stable (beta version) implementation of the formal PDF model for PDF/A-1b
- Prototype the formal PDF model for PDF/A-1a and PDF/A-2b, 3b
- Minor refactoring and stricter naming conventions in validation rules for PDF/A-1b
- Prototype validation rules for PDF/A-1a and PDF/A-2b, 3b
- Prototype implementation of the Metadata Fixer
- Prototype implementation of the plug-in architecture for PDF Feature Report generation
- Optimized performance for PDF/A font rules validation (glyphs presence, widths consistency)

## Infrastructure

- Added cross-platform installer
- Full coverage of Bavaria, Isartor, veraPDF test suites in automated integration tests

## Test corpus

- New test files for the use of Device colour spaces and XMP metadata
- 200 new atomic test files for PDF/A-1b extending Isartor and Bavaria test suites

***

# Version 0.4 (September 16, 2015)

The release includes a fully functional implementation (alpha version) for the complete PDF/A-1B validation and the PDF Feature Report generation

## Features

- A number of bug fixes in the implementation of the formal PDF model for PDF/A Level B validation
- Added missing validation rules for the full coverage of ISO 19005-1:2005, 19005-1:2005/Cor.1:2011, 19005-1:2005/Cor.1:2007, 19005-1:2005/Cor.2:2011, Level B
- Complete implementation of the PDF Feature Report generation
- Minor improvements in the GUI and the Human-readable Report in HTML format
- Added extra parameters to limit the number of rule failures and the number of reported errors
- Optimized performance

## Infrastructure

- Increased unit test coverage to 70%
- Increased the number of atomic validation tests to 226, including the full coverage of tests against Isartor test corpus

## Test corpus

- Total 176 atomic test files for PDF/A-1B extending Isartor test suite

***

# Version 0.2 (July 15, 2015)

The release includes a fully functional prototype for the PDF/A-1b validation and the PDF Feature Report generation

## Features

- The formal PDF model for PDF/A Level B validation
- The set of validation rules covering ISO 19005-1:2005, 19005-1:2005/Cor.1:2011, 19005-1:2005/Cor.1:2007, 19005-1:2005/Cor.2:2011, Level B
- Implementation of the rules covering the following sections of ISO 19005-1:
  - 6.1 File structure
  - 6.2 Graphics
  - 6.4 Transparency
  - 6.5 Annotations
  - 6.6 Actions
  - 6.7 Metadata
  - 6.9 Interactive Forms
- Initial implementation of the PDF Feature Report generation
- Minor improvements in the GUI and the Human-readable Report in HTML format

## Infrastructure

- Fully automated build and deployment procedures based on quality gateways
- More restrictive quality criteria (50% unit test coverage, 80% documentation of public API, zero-tolerance to critical Sonar issues)
- Integration tests framework with 150 atomic validation test

## Test corpus

- Draft set of new test files for ISO 19005-1:
  - 6.1 File structure
  - 6.2 Graphics (under review of veraPDF Technical Workgroup of the PDF Association)

***

# Version 0.1 (June 5, 2015)

This is a minimal viable product release of the veraPDF Conformance Checker

## Features

- Implementation of the generic validation model
- Parser for validation profile
- Initial version of machine-readable reports
- Proof of concept for human-readable reports in HTML format
- Initial version of the CLI interface for the Conformance Checker
- Initial version of the GUI application
- Partial implementation of the COS layer for the PDF/A validation model
- PDF/A-1 validation profiles for ISO 19005-1:2005, 6.1 File structure

## Test corpus

- Draft set of test files for ISO 19005-1:2005, 6.1 File structure

***

<img src="http://verapdf.openpreservation.org/wp-content/uploads/sites/3/2015/06/veraPDF-logo-200.png" width="88" alt="veraPDF Consortium"/>
© 2015 [veraPDF Consortium](http://www.verapdf.org)
